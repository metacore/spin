/*
 * rconsole: Utility program for "chatting" to a remote console terminal line,
 *	using a local tty line.
 *
 * Use: rconsole [-eC] [-l logfile] [-k] name
 *	where name is one of the remote machines listed in /etc/rconsoles.
 *	Any of the available aliases listed in /etc/rconsoles is acceptable.
 *	To terminate the program, type ^_ (CTRL-Underscore).  This escape
 *	character (^_) can be changed through use of the -e option.  No space
 *	should separate the -e option flag from the argument character.
 *	If a script of the console session is desired (in addition to the log
 *	produced by the rconsoled daemon) the -l option can be used.  All
 *	console output will be appended to the end of the file whose name is
 *	specified following the -l flag.  If logfile doesn't exist, it will be
 *	created.  Whether or not the -l option is used, a log of the current
 *	console session will be maintained by the rconsoled daemon, along with
 *	all of the other console activity preceding and following this
 *	session.
 *	The -k flag can be used to kill the rconsoled daemon associated with
 *	the specified remote console.  In this case, no chat session will be
 *	take place, and none will be possible until the daemon is restarted.
 * 
 * HISTORY
 * 02-Apr-96  Marc Fiuczynski (mef) at the University of Washington
 *	Added timeout to automatically give up rconsole line after
 *	default time.  Default is currently set to 30 minutes and can
 *	changed with the -t flag.
 *	14-Jan-86   Bill Bolosky (bolosky) at Carnegie-Mellon University.
 *		Changed to use INET sockets instead of Unix.  Fixed to
 *		allow stdin to not be a tty (check for EOF an halt if not).
 *		Added code to handle a possible password request from
 *		the rconsole daemon.
 *	11-Sep-85  James Wendorf (jww) at Carnegie-Mellon University.
 *		Modified termination character sent to rconsoled, to avoid
 *		accidental termination.  Added check that stdin is a tty.
 *	08-Oct-84  James Wendorf (jww) at Carnegie-Mellon University.
 *		Added -l and -k command line options, and fixed timeout to
 *		work more logically and predictably.
 *	4-Oct-84	Robert V Baron (rvb)		CMU
 *		flush the parity in the esc_char test
 *	02-Oct-84  James Wendorf (jww) at Carnegie-Mellon University.
 *		Added -e command line option.
 *	18-Sep-84  James Wendorf (jww) at Carnegie-Mellon University.
 *		Created.
 */

#include "rconsole.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/time.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <termios.h>
#include <pwd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

char *getpass();

char *name;			/* pgm name */

int debug = 0;			/* local debugging */
int on_tty = 0;			/* stdin is tty */
int log_flag = 0;		/* store to log_file */
char *boot_cmd;
char *log_file = (char *) 0;	/* name of log file */
char esc_char = ESC_CHAR;	/* rconsole escape character */
char *crashbox;
char cbuf[LINE_LENGTH];
char oob_buf[2] = { OOB_CHAR, 0};
char last_char_from_daemon;

int timeout = 30;               /* default time rconsole can be idle before we automatically give up */

int est_conn(char *rcname);
void est_login(int is, int os);
void loop(int is, int os, int log);
void read_daemon(int s, int ofd, int log);
void read_tty(int ifd, int s);

void 
esc_usage ()
{
    printf("  e,q: quit rconsole.\r\n");
    printf("  z: suspend rconsole.\r\n");
    printf("  r, R: reset the remote host.\r\n");
    printf("  p: powercycle the remote host.\r\n");
    printf("  h: halt the remote host.\r\n");
    printf("  l: turn on/off logging.\r\n");
    printf("  D: turn on/off remote daemon debugging.\r\n");
    printf("  d: turn on/off rconsole debugging.\r\n");
}

void 
usage ()
{
    puts("rconsole [options] machine");
    puts("  -t SECONDS: set timeout.");
    puts("  -b CMD: set boot command.  Env var BOOTCMD can be used also.");
    puts("  -d: output debug message.");
    puts("  -e CH: set the escape char.");
    puts("  -k: tell daemon to kill itself.");
    puts("  -l FILE: output log to FILE.");
    puts("ESC sub commands:");
    esc_usage();
    exit(1);
}

struct termios org_tty_params;

void
tty_save (int fd)
{
    if (!on_tty) return;
    if (tcgetattr(fd, &org_tty_params) < 0) {
	perror("tty_save: tcgetattr");
    }
}

void
tty_set (int fd)
{
    struct termios tty_params = org_tty_params;
    if (!on_tty) return;
    tty_params.c_lflag &= ~(ECHO | ICANON | ISIG);
    tty_params.c_oflag = 0;
    tty_params.c_iflag = OCRNL;
    tty_params.c_cflag = CS8|CREAD;

    if (tcsetattr(fd, TCSAFLUSH, &tty_params) < 0) {
	perror("tty_set: tcsetattr");
    }
}

void
tty_restore (int fd)
{
    if (!on_tty) return;
    if (tcsetattr(fd, TCSAFLUSH, &org_tty_params) < 0) {
	perror("tty_restore: tcsetattr");
    }
}

void 
main (int argc, char **argv)
{
    int s;				/* rconsoled socket descriptor */
    int log;			/* File pointer for log file */
    int t;
    int flag;
    int k_flag = 0;			/* tell daemon to self destruct */

    name = basename(*argv);

    while ((flag = getopt(argc, argv, "cde:kl:t:b:")) != EOF) {
	switch (flag) {
	  case 'd':
	    debug = 1;
	    break;
	  case 'e':
	    esc_char = *optarg & 0x7f;
	    break;
	  case 'k':
	    k_flag = 1;
	    break;
	  case 'l':
	    log_file = optarg;
	    log_flag = 1;
	    break;
	  case 't':
	    t = atoi(optarg);
	    if (t > 0)  timeout = t;
	    break;
	  case 'b':
	    boot_cmd = optarg;
	    break;
	  default:
	    usage();
	}
    }
    on_tty = isatty(0);
    if (debug)
      printf("%s: main(); debug %d, on_tty %d, k_flag = %d, log %s, esc %c(%o)\n",
	     name, debug, on_tty, k_flag,
	     log_file,
	     esc_char, esc_char &0xff);

    if (optind >= argc) {
	printf("%s: main();  Machine to connect to not specified.\n", name);
	exit(1);
    }

    if (log_file)
      if ((log = open(log_file, O_RDWR|O_APPEND)) < 0) {
	  printf("%s: main(); Unable to open log file %s - ",
		 name, log_file);
	  fflush(stdout);
	  perror("open");
	  exit(1);
      }
    crashbox = argv[optind];
    s = est_conn(crashbox);
    est_login(s, s);
    if (k_flag) {
	oob_buf[1] = OOB_TERM;
	write(s, oob_buf, 2);
	printf("%s: main(); The daemon has been sent the termination message\n", name);
	exit(0);
    }
    
    if (on_tty){
	tty_save(0);
	tty_set(0);
	if (esc_char < ' ')
	  printf("%s: Type '^%c{q|e}' to exit.\r\n", name, esc_char+'@');
	else
	  printf("%s: Type '%c{q|e}' to exit.\r\n", name, esc_char);
    } else
      printf("%s: main(); Copying file into console tty.\n", name);
    
    loop(s, s, log);
}

int
est_conn (char *rcname)
{
    int s;				/* rconsoled socket descriptor */
    struct sockaddr_in sin;		/* Internet socket address. */
    struct hostent *hp;		/* Internet host entry. */
    char rcon_name[20];		/* Common name for remote machine */
    char rcon_tty[25];		/* Path name of tty connected to rem. mach. */
    u_short serv_port;		/* INET port number for server. */

    if (lookup_machine(rcname, rcon_name, rcon_tty, &serv_port, &hp) < 0) {
	printf("%s: est_conn(); %s does not have a rconsole line.\n", name, rcname);
	exit(1);
    }

    if (debug)
      printf("%s: est_conn(); name %s, real name %s, tty %s, port %d\n",
	     name, rcname, rcon_name, rcon_tty, ntohs(serv_port));
    
    if (hp == NULL) {
	printf("%s: est_conn(); server host not in network database.\n", name);
	exit(1);
    }
    if (debug)
      printf("%s: est_conn(); daemon %s, addr type %d, addr len %d, addr %x\n",
	     name, hp->h_name, hp->h_addrtype, hp->h_length,
	     (int *)&hp->h_addr);


    printf("Attempting to connect to %s (via %s) ... ",
	   rcon_name, rcon_tty);

    bzero((char *)&sin, sizeof(sin));
    sin.sin_family = hp->h_addrtype;
    bcopy(hp->h_addr, (char *)&sin.sin_addr, hp->h_length);
    sin.sin_port = serv_port;
    if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	printf("%s: est_conn(); ", name);
	fflush(stdout);
	perror("socket");
	exit(1);
    }
    if (connect(s, (struct sockaddr*)&sin, sizeof(sin)) < 0) {
	printf("%s: est_conn(); ", name);
	fflush(stdout);
	perror("connect");
	exit(1);
    }
    if (debug) {
	struct sockaddr_in sname; int len = sizeof (struct sockaddr);
	if (getpeername(s, (struct sockaddr *) &sname, &len) < 0) {
	    printf("%s: est_conn(); ", name);
	    fflush(stdout);
	    perror("getpeername");
	}
	printf("\n%s: est_conn(); connected to %x socket %d",
	       name, ntohl(sname.sin_addr.s_addr), ntohs(sname.sin_port));
    }
    return s;
}

void 
est_login (int is, int os)
{
    int readfds;
    int cnt;
    struct timeval timeout;		/* Time limit for use with select */

    timeout.tv_sec = TIME_LIMIT;
    timeout.tv_usec = 0;
    readfds = 1 << is;
    if (select(is+1, &readfds, 0, 0, &timeout) <= 0) {
	printf("Failed\n");
	printf("%s: est_login(); This console line is currently in use\n", name);
	exit(1);
    }
    printf("Connected\n");
    
    
    if ((cnt = read(is, cbuf, sizeof (cbuf))) <= 0) {
	printf("%s: est_login(); read %d chars from daemon.\n", name, cnt);
	fflush(stdout);
	perror("read");
	exit(2);
    }
    if (debug)
      printf("%s: est_login(); daemon '%s',%d chars\n", name, cbuf,cnt);
    
    switch(*cbuf) {
      case 'a':
	{ /* We need to send the password. */
	    char *passwd;
	    passwd = getpass("Password: ");
	    write(os, passwd, strlen(passwd) + 1);  /* +1 sends \0 */
	  check_passwd:
	    if ((cnt = read(is, cbuf, 1)) != 1) {
		printf("%s: est_login(); error reading daemon %d\n", name, cnt);
		fflush(stdout);
		perror("read");
		exit(2);
	    }
	  refuse:
	    if (*cbuf == 'n') {
		printf("%s: est_login(); Invalid password.  Connection refused.\n",
		       name);
		exit(1);
	    }
	}
	break;
      case 'b':
	{ /* We need to send the password. */
	    char *passwd;
	    char hostname[100];		/* for gethostname() */
	    char loginfo[100];
	    int uid = getuid();
	    struct passwd *pdp = getpwuid(uid);
	    
	    passwd = getpass("Password: ");
	    if (gethostname(hostname, sizeof hostname) < 0) {
		printf("%s: est_login(); gethostname \"%s\" failure, ", name, hostname);
		fflush(stdout);
		perror("gethostbyname");
		exit(1);
	    }
	    if (pdp == NULL) {
		printf("%s: est_login(): getpwuid \"%d\" failure, ", name, uid);
		exit(1);
	    }
	    if (debug)
	      printf("%s: est_login(); hostname %s, user %s\n",
		     name, hostname, pdp->pw_name);
	    sprintf(loginfo, "%s %s@%s",
		    passwd, pdp->pw_name, hostname);
	    
	    write(os, loginfo, strlen(loginfo) + 1);  /* +1 sends \0 */
	    goto check_passwd;
	}
	break;
      case 'n':
	if (debug)
	  printf("%s: est_login(); Daemon already in use.\n", name);
	
	printf("%s", cbuf+1);
	exit(1);
	
      case '\n':
	if (debug)
	  printf("%s: est_login(); No password needed.\n", name);
	break;
      default:
	printf("%s: est_login(); rconsole DAEMON returned %c [0x%x]. Abort.\n", name, *cbuf,*cbuf);
	exit(1);
    }
}

void 
loop (int is, int os, int log)
{
    fd_set READFDS;
    fd_set readfds;
    struct timeval tv;
    int done = 0; /* TRUE */
    
    FD_ZERO(&READFDS);
    FD_SET(0, &READFDS);
    FD_SET(is, &READFDS);

    /* If we block in select for 15 minutes, then there
       was no input from either the rconsole host or the
       user's host. At that point we will give up the 
       rconsole.
       */
    tv.tv_sec  = timeout*60;
    tv.tv_usec = 0;
    if (debug) {
	printf("in loop is=%d.\n", is);
    }
    while(1) {
	readfds = READFDS;
	if ((done = select(is+1, &readfds, 0, 0, &tv)) < 0) {
	    printf("%s: loop(); ", name);
	    fflush(stdout);
	    perror("select");
	    exit(1);
	}
	if (done == 0) { /* select returns zero if timeout occurs */
	    printf("%s: idle for too long.  Giving up rconsole.\n", name);
	    fflush(stdout);
	    tty_restore(0);
	    exit(1);
	}
	
	/* read from socket to daemon */
	if (FD_ISSET(is, &readfds))
	  read_daemon(is, 1, log);
	
	/* read from tty */
	if (FD_ISSET(0, &readfds))
	  read_tty(0, os);
    }
}

void 
read_daemon (int s, int ofd, int log)
{
    register int cnt;
    register int c;
    register int i;
    
    if ((cnt = read(s, cbuf, sizeof cbuf)) <= 0) {
	printf("%s: read_daemon(); error reading daemon %d\n", name, cnt);
	fflush(stdout);
	perror("read");
	exit(2);
    }
    last_char_from_daemon = cbuf[cnt-1];
    if (debug) {
	cbuf[cnt]=0;
	printf("\n%s: read_daemon(); %s cnt = %d\r\n", name, cbuf, cnt);
	fflush(stdout);
    }

#ifdef PARITY
    for (i = 0; i < cnt; i++) 
      cbuf[i] &= ~0200;		/* deal with parity, the crude way */
#endif PARITY
    
    if (write(ofd, cbuf, cnt) != cnt) {
	printf("%s: read_daemon(); error writing tty %d\n", name, cnt);
	fflush(stdout);
	perror("write");
    }

    /* and possibly log */
    if (log_file) {
	register char *cp=cbuf, *sp=cbuf, *ep = &cbuf[cnt];
	while (cp < ep)
	  if ((c = *cp++) == '\r') {
	      if (sp < cp)
		if (log_flag) write(log, sp, cp - sp - 1);
	      sp = cp;
	  }
	if (sp < cp)
	  if (log_flag) write(log, sp, cp - sp);
    }
}

/* We are essentially reinventing stdio below.  We can't afford to do a getc()
 * because we are called from a loop doing a select so that when
 * our initial load of characters is read we must return.
 */
int esc_flag = 0;

#define flush if (sp < cp - (esc_flag?1:0)) write(s, sp, cp - sp - (esc_flag?1:0));\
if(debug)printf("%dN\r\n",cp - sp - (esc_flag?1:0)),fflush(stdout)
     
     void 
     read_tty (int ifd, int s)
{
    int cnt;
    char *cp, *sp, *ep;
    int c;
    char *macro;

    if ((cnt = read(ifd, cbuf, sizeof cbuf)) <= 0) {
	printf("%s: read_tty(); error reading tty %d\n", name, cnt);
	fflush(stdout);
	perror("read");
	goto out;
    }
    if (debug) {
	cbuf[cnt]=0;
	printf("%s: read_tty(); %s cnt = %d\n", name, cbuf, cnt);
	fflush(stdout);
    }

    for (cp=cbuf, sp=cbuf, ep = &cbuf[cnt]; cp < ep; cp++) {
	if ((c = (*cp &= 0177)) == esc_char) {
	    if (++esc_flag > 1) {
		esc_flag = 0;	/* two esc_chars go through as one. */
		/* flush;	/* first esc flushed */
		/* sp = cp + 1;	/* leave pointer so we output esc char */
	    }
	} else if (esc_flag) {	/* we'd need to read to get next char */
	    flush;
	    sp = cp+1;		/* step over esc char */
	    esc_flag = 0;
	    switch(c) {
	      case 'd':
		debug = ! debug;
		printf("esc d (debug client), debug = %d\n",
		       name, debug);
		break;
	      case 'D':
		printf("esc s (debug daemon)\n", name);
		oob_buf[1] = OOB_DEBUG;
		write(s, oob_buf, 2);
		break;
	      case 'q':
	      case 'e':
		printf("esc \"quit\" (exit client)\r\n", name);
		goto out;
		break;
	      case 'l':
		log_flag = ! log_flag;
		printf("esc l (log local), log_flag = %d\n",
		       name, log_flag);
		break;
	      case 'L':
		printf("esc L (log daemon)\n", name);
		oob_buf[1] = OOB_LOG;
		write(s, oob_buf, 2);
		break;
	      case 't':		/* would you believe a macro */
		printf("esc t (send wt*=80a0)\n", name);
		macro = "wt0=80a0wt1=80a0wpra";
		write(s, macro, strlen(macro));
		break;
	      case 'z':
		printf("esc z (suspend client)\n", name);
		tty_restore(ifd);
		kill(0, SIGTSTP);
		tty_set(ifd);
		break;
	      case 'r':
	      case 'R':
		printf ("esc \"reset\" (reset host)\n",name);
		oob_buf[1] = OOB_DTR;
		write (s, oob_buf, 2);
		break;
	      case 'b': {
		  char buf[1024];
		  char *user = getenv("USER");
		  char *boot = getenv("BOOTCMD");
		  
		  if (boot_cmd) {
		      sprintf(buf, "%s\r\n", boot_cmd);
		  } else if (boot) {
		      sprintf(buf, "%s\r\n", boot);
		  } else if (!strncmp(crashbox, "loom", 4)) {
		      printf("PC boot.\r\n");
		      sprintf(buf, "b /spin/%s/spin.x86\r\n", user);
		  } else if (last_char_from_daemon == '>') {
		      printf("pci alpha boot.\r\n");
		      sprintf(buf, "b -fi \"/spin/%s/spin.boot\" ewa0\r\n", user);
		  } else {
		      printf("old alpha boot.\r\n");
		      sprintf(buf, "b -fi \"/spin/%s/spin.boot\" ez0\r\n", user);
		  }
		  write (s, buf, strlen(buf));
		  break;
	      }
		
	      case 'p': {
		  char buf[1024];
		  sprintf(buf, "power %s", crashbox);
		  system(buf);
		  break;
	      }
	      case 'h': {
		  char buf[1024];
		  sprintf(buf, "haltcrash %s", crashbox);
		  system(buf);
		  break;
	      }
	      default:
		esc_usage();
		break;
	    }
	}
    }
    flush;
    return;
  out:
    if (on_tty)
      tty_restore(ifd);
    exit(0);
}

/* 
 * XXX raj
 * dummy fopenp, which we don't have unless we're running Mach
 */
fopenp()
{
	return(0);	/* NULL */
}

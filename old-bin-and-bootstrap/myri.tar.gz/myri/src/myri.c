
#include <sys/param.h>			/* ALWAYS included */
#include <sys/ioctl.h>
#include <sys/mbuf.h>
#include <net/if.h>

#include "compile/SPIN/myri.h"
#include <myricom/include/mcpConstants.h>
#include <netinet/in.h>
#include <sys/device.h>
#include <netinet/if_ether.h>
#include <pci/myrivar.h>

#ifdef OSF
#include "../../netdev/ALPHA_SPIN/EtherDev.h"
#endif
#ifdef __FreeBSD__
#include "../../netdev/IX86_SPIN/EtherDev.h"
#endif

ifpup(register struct ifnet *ifp)
{
	ifp->if_flags |= IFF_UP;
	ifp->if_ioctl(ifp,SIOCSIFFLAGS,0);
}

static void *myridev; /* XXX need something to generally track NetDev.Ts */

/* called in myri intr handler */
void
myrilisten(struct ifnet *ifp)
{
	struct mbuf *m;

	IF_DEQUEUE(&ifp->if_rcv,m);
	while(m) {
		(*EtherDev__Receive)(myridev, m);
		IF_DEQUEUE(&ifp->if_rcv,m);
		}
}

install_myrilisten(void *dev, struct ifnet *ifp)
{
	myridev = dev;
	ifp->if_recv = myrilisten;
}

extern struct myri_softc *myris[NMYRI];

hwaddr(struct ifnet *ifp, char *etheraddr)
{
	bcopy(myris[ifp->if_unit]->myri_addr, etheraddr, 6);
}

/*
 * This file is te-i386aix.h and is built from pieces of code from Minh Tran-Le
 * <TRANLE@INTELLICORP.COM> by rich@cygnus.com.
 */

#define TE_I386AIX 1

#include "obj-format.h"

#define KEEP_RELOC_INFO

/*
 * Local Variables:
 * comment-column: 0
 * fill-column: 79
 * End:
 */

/* end of te-i386aix.h */

/* Generated automatically by the program `genconfig'
from the machine description file `md'.  */


#define MAX_RECOG_OPERANDS 10

#define MAX_DUP_OPERANDS 3
#ifndef MAX_INSNS_PER_SPLIT
#define MAX_INSNS_PER_SPLIT 1
#endif
#define REGISTER_CONSTRAINTS
#define HAVE_cc0

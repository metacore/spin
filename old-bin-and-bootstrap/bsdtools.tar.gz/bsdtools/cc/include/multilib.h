#define MULTILIB_SELECT "\
. ;\
"
